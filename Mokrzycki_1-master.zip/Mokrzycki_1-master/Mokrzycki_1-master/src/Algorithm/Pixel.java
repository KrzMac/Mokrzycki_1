package Algorithm;

/**
 * Created by KMacioszek on 2016-05-09.
 */
public class Pixel {

    int red, blue, green;

    public Pixel() {
        this.red = 0;
        this.blue = 0;
        this.green = 0;
    }

    public Pixel(int red, int green, int blue) {
        this.red = red;
        this.green = green;
        this.blue = blue;
    }

    public int getRed() {
        return red;
    }

    public int getGreen() {
        return green;
    }

    public int getBlue() {
        return blue;
    }
}
