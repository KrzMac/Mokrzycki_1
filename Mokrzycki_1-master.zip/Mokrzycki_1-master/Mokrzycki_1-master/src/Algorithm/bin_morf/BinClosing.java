package Algorithm.bin_morf;

import java.awt.image.BufferedImage;

/**
 * Created by MSI on 2016-04-20.
 */
public class BinClosing {
    private BufferedImage templateImage;

    public BinClosing(BufferedImage bufferedImage, String path) {
        BinDilation binDilation = new BinDilation(bufferedImage, path);
        BinErosion binErosion = new BinErosion(binDilation.getTemplateImage(), path);

        this.templateImage = binErosion.getTemplateImage();
    }

    public BufferedImage getTemplateImage() {
        return templateImage;
    }
}