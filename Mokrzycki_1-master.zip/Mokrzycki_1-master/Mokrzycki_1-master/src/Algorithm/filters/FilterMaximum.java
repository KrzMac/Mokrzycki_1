package Algorithm.filters;

import java.awt.image.BufferedImage;

/**
 * Created by KMacioszek on 2016-05-10.
 */
public class FilterMaximum extends Filters {

    public FilterMaximum(BufferedImage bufferedImage, String path) {
        super(bufferedImage, path);

        setMaximum(true);
        run();
    }

    @Override
    protected Integer[][] chooseFilterMask() {
        return new Integer[3][3];
    }
}
