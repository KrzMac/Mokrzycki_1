package Algorithm.filters;

import java.awt.image.BufferedImage;

/**
 * Created by KMacioszek on 2016-05-06.
 */
public class FilterLowPass1 extends Filters {

    public FilterLowPass1(BufferedImage bufferedImage, String path) {
        super(bufferedImage, path);

        run();
    }

    @Override
    protected Integer[][] chooseFilterMask() {
        return new Integer[][] {
                {1, 1, 1},
                {1, 1, 1},
                {1, 1, 1}
        };
    }
}
