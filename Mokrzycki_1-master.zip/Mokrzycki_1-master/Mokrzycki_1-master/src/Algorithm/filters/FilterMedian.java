package Algorithm.filters;

import java.awt.image.BufferedImage;

/**
 * Created by KMacioszek on 2016-05-09.
 */
public class FilterMedian extends Filters {

    public FilterMedian(BufferedImage bufferedImage, String path) {
        super(bufferedImage, path);

        setMedian(true);
        run();
    }

    @Override
    protected Integer[][] chooseFilterMask() {
        return new Integer[3][3];
    }
}
