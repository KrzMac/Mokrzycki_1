package Algorithm.gray_morf;

import java.awt.image.BufferedImage;

/**
 * Created by MSI on 2016-04-21.
 */
public class GrayClosing {
    private BufferedImage templateImage;

    public GrayClosing(BufferedImage bufferedImage, String path) {
        GrayDilation grayDilation = new GrayDilation(bufferedImage, path);
        GrayErosion grayErosion = new GrayErosion(grayDilation.getTemplateImage(), path);

        this.templateImage = grayErosion.getTemplateImage();
    }

    public BufferedImage getTemplateImage() {
        return templateImage;
    }
}
