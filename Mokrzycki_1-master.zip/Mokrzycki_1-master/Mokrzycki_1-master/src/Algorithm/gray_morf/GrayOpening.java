package Algorithm.gray_morf;

import java.awt.image.BufferedImage;

/**
 * Created by MSI on 2016-04-21.
 */
public class GrayOpening {

    private BufferedImage templateImage;

    public GrayOpening(BufferedImage bufferedImage, String path) {
        GrayErosion grayErosion = new GrayErosion(bufferedImage, path);
        GrayDilation grayDilation = new GrayDilation(grayErosion.getTemplateImage(), path);

        this.templateImage = grayDilation.getTemplateImage();
    }

    public BufferedImage getTemplateImage() {
        return templateImage;
    }
}
