package Algorithm.operacje_geometryczne;

import Algorithm.Algorithm;

import java.awt.image.BufferedImage;

/**
 * Created by KMacioszek on 2016-05-10.
 */
public class AspectRatioScale extends Algorithm {

    protected int inWidth, inHeight;
    protected int width, height;

    public AspectRatioScale(BufferedImage image, String path) {
        super(image, path);
    }

    public void calculate() {
        run();
    }

    @Override
    protected void run() {
        int originalWidth, originalHeight;

        originalHeight = bufferedImage.getHeight();
        originalWidth = bufferedImage.getWidth();

        double sX = (double) origi
    }

    public void setInHeight(int inHeight) {
        this.inHeight = inHeight;
    }

    public void setInWidth(int inWidth) {

        this.inWidth = inWidth;
    }

    public int getHeight() {
        return height;
    }

    public int getWidth() {
        return width;
    }
}
