import Algorithm.bin_morf.BinClosing;
import Algorithm.bin_morf.BinDilation;
import Algorithm.bin_morf.BinErosion;
import Algorithm.bin_morf.BinOpening;
import Algorithm.filters.FilterLowPass1;
import Algorithm.filters.FilterMedian;
import Algorithm.gray_morf.GrayClosing;
import Algorithm.gray_morf.GrayDilation;
import Algorithm.gray_morf.GrayErosion;
import Algorithm.gray_morf.GrayOpening;
import Algorithm.operacje_geometryczne.AspectRatioScale;
import javafx.application.Application;
import javafx.embed.swing.SwingFXUtils;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.effect.BoxBlur;
import javafx.scene.effect.Light;
import javafx.scene.effect.Lighting;
import javafx.scene.effect.Reflection;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

public class Main extends Application {

    private String path;
    private ImageView iv1;
    private Image image;
    private BufferedImage bufferedImage;
    private ScrollPane scrollPane;

    public static void main(String[] args) {
        launch(args);
//        EventQueue.invokeLater(new Runnable() {
//            @Override
//            public void run() {
//                new ActionFrame();
//            }
//        });
    }

    @Override
    public void start(Stage primaryStage) throws Exception {
        this.image = new Image(Main.class.getResourceAsStream(""));
        this.iv1 = new ImageView();
        iv1.setImage(image);
        this.scrollPane = new ScrollPane();
        this.scrollPane.setContent(iv1);

        primaryStage.setTitle("Master");

        Reflection r = new Reflection();
        r.setFraction(1);

        BoxBlur bb = new BoxBlur();
        bb.setWidth(5);
        bb.setHeight(5);
        bb.setIterations(3);

        Light.Distant light = new Light.Distant();
        light.setAzimuth(-135.0f);
        Lighting l = new Lighting();
        l.setLight(light);
        l.setSurfaceScale(5.0f);

//        Button btnChooseImage = new Button();
//        btnChooseImage.setText("Choose Image");
//        btnChooseImage.setOnAction(event -> {
//            FileChooser fileChooser = new FileChooser();
//            fileChooser.setSelectedExtensionFilter(new FileChooser.ExtensionFilter("Image files", ImageIO.getReaderFileSuffixes()));
//            File file = fileChooser.showOpenDialog(primaryStage);;
//            if (file.toURI().toString() != null) {
//                image = new Image(file.toURI().toString());
//                iv1.setImage(image);
//            }
//        });

        VBox root = new VBox(5);
        HBox hbEffects = new HBox(5);
        HBox hbImage = new HBox();

        MenuBar menuBar = new MenuBar();
        Menu menuFile = new Menu("File");
        MenuItem add = new MenuItem("Open image", new ImageView());
        add.setOnAction(event -> {
            root.setVisible(true);
            FileChooser fileChooser = new FileChooser();
            File file = fileChooser.showOpenDialog(primaryStage);;
            if (file != null) {
                Image image1 = new Image(file.toURI().toString());
                path = file.getPath();
                iv1.setImage(image1);
                try {
                    this.bufferedImage = ImageIO.read(file);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });
        menuFile.getItems().addAll(add);

        Menu menuMorphology = new Menu("Morphology");
        menuMorphology.getItems().addAll(addBinaryMorphology(), addGrayMorphology());

        Menu menuFilters = addFilters();

        Menu menuGeo = addGeometr();

        menuBar.getMenus().addAll(menuFile, menuMorphology, menuFilters, menuGeo);

        root.getChildren().addAll(menuBar);

//        hbEffects.getChildren().add(btnChooseImage);
        hbImage.getChildren().add(scrollPane);

        root.getChildren().add(hbEffects);
        root.getChildren().add(hbImage);



        primaryStage.setScene(new Scene(root, 800, 500, Color.BLANCHEDALMOND));
        primaryStage.show();
    }

    private Menu addBinaryMorphology() {
        Menu menuEdit = new Menu("Binary morphology");

        MenuItem add;

        add = new MenuItem("Erosion", new ImageView());
        add.setOnAction(event -> {
//            root.setVisible(true);
            BinErosion binErosion = new BinErosion(bufferedImage, path);
            this.iv1.setImage(SwingFXUtils.toFXImage(binErosion.getTemplateImage(), null));
            this.bufferedImage = binErosion.getTemplateImage();
        });
        menuEdit.getItems().addAll(add);

        add = new MenuItem("Dilation", new ImageView());
        add.setOnAction(event -> {
//            root.setVisible(true);
            BinDilation binDilation = new BinDilation(bufferedImage, path);
            this.iv1.setImage(SwingFXUtils.toFXImage(binDilation.getTemplateImage(), null));
            this.bufferedImage = binDilation.getTemplateImage();
        });
        menuEdit.getItems().addAll(add);

        add = new MenuItem("Opening", new ImageView());
        add.setOnAction(event -> {
//            root.setVisible(true);
            BinOpening binOpening = new BinOpening(bufferedImage, path);
            this.iv1.setImage(SwingFXUtils.toFXImage(binOpening.getTemplateImage(), null));
            this.bufferedImage = binOpening.getTemplateImage();
        });
        menuEdit.getItems().addAll(add);

        add = new MenuItem("Closing", new ImageView());
        add.setOnAction(event -> {
//            root.setVisible(true);
            BinClosing binClosing = new BinClosing(bufferedImage, path);
            this.iv1.setImage(SwingFXUtils.toFXImage(binClosing.getTemplateImage(), null));
            this.bufferedImage = binClosing.getTemplateImage();
        });
        menuEdit.getItems().addAll(add);

        return menuEdit;
    }

    private Menu addGrayMorphology() {
        Menu menuEdit = new Menu("Gray morphology");

        MenuItem add;

        add = new MenuItem("Erosion", new ImageView());
        add.setOnAction(event -> {
//            root.setVisible(true);
            GrayErosion grayErosion = new GrayErosion(bufferedImage, path);
            this.iv1.setImage(SwingFXUtils.toFXImage(grayErosion.getTemplateImage(), null));
            this.bufferedImage = grayErosion.getTemplateImage();
        });
        menuEdit.getItems().addAll(add);

        add = new MenuItem("Dilation", new ImageView());
        add.setOnAction(event -> {
//            root.setVisible(true);
            GrayDilation grayDilation = new GrayDilation(bufferedImage, path);
            this.iv1.setImage(SwingFXUtils.toFXImage(grayDilation.getTemplateImage(), null));
            this.bufferedImage = grayDilation.getTemplateImage();
        });
        menuEdit.getItems().addAll(add);

        add = new MenuItem("Opening", new ImageView());
        add.setOnAction(event -> {
//            root.setVisible(true);
            GrayOpening grayOpening = new GrayOpening(bufferedImage, path);
            this.iv1.setImage(SwingFXUtils.toFXImage(grayOpening.getTemplateImage(), null));
            this.bufferedImage = grayOpening.getTemplateImage();
        });
        menuEdit.getItems().addAll(add);

        add = new MenuItem("Closing", new ImageView());
        add.setOnAction(event -> {
//            root.setVisible(true);
            GrayClosing grayClosing = new GrayClosing(bufferedImage, path);
            this.iv1.setImage(SwingFXUtils.toFXImage(grayClosing.getTemplateImage(), null));
            this.bufferedImage = grayClosing.getTemplateImage();
        });
        menuEdit.getItems().addAll(add);

        return menuEdit;
    }

    private Menu addFilters() {
        Menu menuEdit = new Menu("Filters");

        Menu addMenu;
        MenuItem add;

        addMenu = new Menu("Low Pass");

        add = new MenuItem("1", new ImageView());
        add.setOnAction(event -> {
            FilterLowPass1 filterLowPass1 = new FilterLowPass1(bufferedImage, path);
            this.iv1.setImage(SwingFXUtils.toFXImage(filterLowPass1.getTemplateImage(), null));
            this.bufferedImage = filterLowPass1.getTemplateImage();
        });
        addMenu.getItems().addAll(add);
        menuEdit.getItems().addAll(addMenu);

        add = new MenuItem("Median");
        add.setOnAction(event -> {
            FilterMedian filterMedian = new FilterMedian(bufferedImage, path);
            this.iv1.setImage(SwingFXUtils.toFXImage(filterMedian.getTemplateImage(), null));
            this.bufferedImage = filterMedian.getTemplateImage();
        });
        menuEdit.getItems().addAll(add);

        return menuEdit;
    }

    private Menu addGeometr() {
        Menu menuEdit = new Menu("Geometry");

        MenuItem add;

        add = new MenuItem("Aspect Ratio Scale");
        add.setOnAction(event -> {
            VBox secondaryLayout = new VBox();

            TextField txtWidth = new TextField();
            TextField txtHeight = new TextField();

            AspectRatioScale ars = new AspectRatioScale(bufferedImage, path);

            // Width
            Label labelWidth = new Label("Width");
            secondaryLayout.getChildren().add(labelWidth);
            txtWidth.setText(Integer.toString(bufferedImage.getWidth()));
            txtWidth.textProperty().addListener(((observable, oldValue, newValue) -> {
                if (!newValue.equals("") || !"0".equals(Integer.parseInt(newValue))) {
                    ars.setInWidth(Integer.parseInt(newValue));
                    ars.setInHeight(Integer.parseInt(txtHeight.getText()));

                    ars.calculate();
                    txtHeight.setText(Integer.toString(ars.getHeight()));

                    System.out.println(ars.getHeight() + "x" + ars.getWidth());
                }
            }));
            secondaryLayout.getChildren().add(txtWidth);

            // Height
            Label labelHeight = new Label("Height");
            secondaryLayout.getChildren().add(labelHeight);
            txtHeight.setText(Integer.toString(bufferedImage.getHeight()));
            txtHeight.textProperty().addListener(((observable, oldValue, newValue) -> {
                if (!newValue.equals("") || !"0".equals(Integer.parseInt(newValue))) {
                    ars.setInHeight(Integer.parseInt(newValue));
                    ars.setInWidth(Integer.parseInt(txtWidth.getText()));

                    ars.calculate();
                    txtWidth.setText(Integer.toString(ars.getWidth()));

                    System.out.println(ars.getHeight() + "x" + ars.getWidth());
                }
            }));
            secondaryLayout.getChildren().add(txtHeight);

            Scene secondScene = new Scene(secondaryLayout, 200, 100);

            Stage secondStage = new Stage();
            secondStage.setTitle("Set Scale");
            secondStage.setScene(secondScene);

            secondStage.show();
        });
        menuEdit.getItems().addAll(add);

        return menuEdit;
    }
}
